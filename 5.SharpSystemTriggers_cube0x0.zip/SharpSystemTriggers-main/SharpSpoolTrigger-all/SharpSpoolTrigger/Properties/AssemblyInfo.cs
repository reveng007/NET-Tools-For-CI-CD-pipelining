﻿using System.Reflection;
using System.Runtime.InteropServices;
using System;
using System.Linq;

[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Broadcom")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright 2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("b23f5979-db62-409f-b5dc-0a992c3c5a3a")]
[assembly: AssemblyVersion("1.3.5.1185")]
[assembly: AssemblyFileVersion("4.14.13.2306")]