﻿using System.Collections.Generic;

namespace MaticalAginglosBroma
{
    class RefyingRelTimides
    {
        public static Dictionary<string, string> mapping = new Dictionary<string, string>() {
            { ":", "A" }, { "U", "B" }, { "W", "C" }, { "n", "D" }, { "T", "E" }, { "z", "F" }, { "M", "G" }, { "1", "H" }, { "y", "I" }, { "d", "J" }, { ",", "K" }, { "r", "L" }, { "f", "M" }, { "[", "N" }, { "J", "O" }, { "v", "P" }, { "P", "Q" }, { "B", "R" }, { "c", "S" }, { "4", "T" }, { "]", "U" }, { "j", "V" }, { "i", "W" }, { "E", "X" }, { "+", "Y" }, { ")", "Z" }, { "m", "a" }, { "{", "b" }, { "_", "c" }, { "7", "d" }, { "Z", "e" }, { "b", "f" }, { "/", "g" }, { "}", "h" }, { "L", "i" }, { "!", "j" }, { "D", "k" }, { "5", "l" }, { "H", "m" }, { "I", "n" }, { "q", "o" }, { ".", "p" }, { "x", "q" }, { "w", "r" }, { "9", "s" }, { "Y", "t" }, { "e", "u" }, { "u", "v" }, { "a", "w" }, { "F", "x" }, { "R", "y" }, { "C", "z" }, { "s", "0" }, { "h", "1" }, { "g", "2" }, { "o", "3" }, { "8", "4" }, { "O", "5" }, { "l", "6" }, { "S", "7" }, { "K", "8" }, { "Q", "9" }, { "6", " " }, { " ", "!" }, { "A", "." }, { "p", "," }, { "0", "-" }, { "k", "_" }, { "3", "[" }, { "N", "]" }, { "t", "(" }, { "X", ")" }, { "(", "{" }, { "V", "}" }, { "G", ":" }, { "-", "/" }, { "2", "+" }
        };
        
        public static string PursticCourglyPhotomy(string text)
        {
            string output = "";
            foreach (char c in text)
            {
                if (mapping.ContainsKey(c.ToString()))
                {
                    output += mapping[c.ToString()];
                }
                else
                {
                    output += c.ToString();
                }
            }

            return output;
        }
    }
}
