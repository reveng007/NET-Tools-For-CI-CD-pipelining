﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;

namespace AqualNonrienicDezkiriae
{
    internal class BoularlCarousCration
    {
        private static void Main(string[] ShipstiteUnismStarse)
        {
            string[] BlePatitierInhildahs;
            if (ShipstiteUnismStarse.Length < 1)
            {
                Console.WriteLine(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("]5W+N(YXxd!xQx/<Z_XS/Xq/B5W+/qvXZvX/!6/E5+x>"));
                Console.WriteLine(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("]5W+N(YXxd!xQx/!\\Qpe\\BdHlZlV06!6"));
                return;
            }

            if (File.Exists(ShipstiteUnismStarse[0]))
            {
                BlePatitierInhildahs = File.ReadAllLines(ShipstiteUnismStarse[0]);
            }
            else
            {
                Console.WriteLine(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis(".qv+W/VqX/E5VW/E5+x"));
                Console.WriteLine(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("]5W+N(YXxd/<Z_XS/Xq/B5W+/qvXZvX>"));
                return;
            }

            bool TrohersAbsBesens = false;
            string ElenessYaryNeal = HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("pe");
            string MutedlyThiselinePreheap = HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("");
            string MusketCosSes = HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("");
            foreach (string line in BlePatitierInhildahs)
            {
                if (line.Contains(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("0]h2)0zYZxfqlB_XjXl5V-/=")))
                {
                    TrohersAbsBesens = true;
                }

                if (TrohersAbsBesens)
                {
                    MutedlyThiselinePreheap += System.String.Format(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("}uL\n"), line);
                }

                if (line.Contains(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("////L;")))
                {
                    TrohersAbsBesens = false;
                }

                if (line.Contains(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("/Qwp/jX_6a/d5Cx9qEEdxX/")))
                {
                    ElenessYaryNeal = HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("wp");
                }
            }

            foreach (string line in BlePatitierInhildahs)
            {
                if (line.Contains(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("0]h2)0Alq6fqlB_XjXl5V-/=")))
                {
                    TrohersAbsBesens = true;
                }

                if (TrohersAbsBesens)
                {
                    MusketCosSes += System.String.Format(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("}uL\n"), line);
                }

                if (line.Contains(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("////L;")))
                {
                    TrohersAbsBesens = false;
                }

                if (line.Contains(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("/Qwp/jX_6a/d5Cx9qEEdxX/")))
                {
                    ElenessYaryNeal = HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("wp");
                }
            }

            try
            {
                byte[] AntalistThylmersElukes = BromolParcatestBitatin.TableUredNic(MutedlyThiselinePreheap);
                Console.WriteLine(System.String.Format(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("Zl5{_Xx/dX_X56/IYXx1i/]h2)0zYZxfqlB_XjXl5V-Q}uL/=/Vx /IYXx1i/}}"), ElenessYaryNeal) + EncillivePraelAlookker(AntalistThylmersElukes).TrimEnd(new char[]{' ', ','}) + HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("L;"));
                byte[] ExpecallyOverNontive = BromolParcatestBitatin.TableUredNic(MusketCosSes);
                Console.WriteLine(System.String.Format(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("Zl5{_Xx/dX_X56/IYXx1i/]h2)0Alq6fqlB_XjXl5V-Q}uL/=/Vx /IYXx1i/}}"), ElenessYaryNeal) + EncillivePraelAlookker(ExpecallyOverNontive).TrimEnd(new char[]{' ', ','}) + HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("L;"));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static string EncillivePraelAlookker(byte[] SkersScoloraNonmen)
        {
            var ManullyAetorCalocker = new StringBuilder(SkersScoloraNonmen.Length * 3);
            for (var ForcesBryomeInted = 0; ForcesBryomeInted < SkersScoloraNonmen.Length; ForcesBryomeInted++)
                ManullyAetorCalocker.AppendFormat(NumberFormatInfo.InvariantInfo, HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("uQ}uOQNLF/"), SkersScoloraNonmen[ForcesBryomeInted]);
            return ManullyAetorCalocker.ToString();
        }
    }

    public static class BromolParcatestBitatin
    {
        public static byte[] TableUredNic(string BobotherIntrailShirlwish)
        {
            int LatedMinaceStrion = 0;
            List<byte> UnismFlyHugging = new List<byte>();
            Regex LiquoqianAmmonicViter = new Regex(HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("\nuQ/s?<IYXx>1uHy_HE8Hfi}:FNLM/\\d*/F\n|\ngWlf6jSqlX/\\s/\\d*/uQ/s?<dSqlX>1uHy_HE8Hfi}:FeLM/\\d*/\\M\n|\ngWlf6)qV-/\\s/\\d*/uQ/s?<+qV->1uHy_HE8HfirM/\\d*/\\M\n|\n\\V/\\9\\*/\\d*/s?<qEEdxX>\\WrM*/\\d*/\\*\\9\n|\n\\9\\*/!*/\\*\\9\n"), RegexOptions.IgnorePatternWhitespace);
            while (true)
            {
                Match CoatRobblityInized = LiquoqianAmmonicViter.Match(BobotherIntrailShirlwish, LatedMinaceStrion);
                if (!CoatRobblityInized.Success)
                {
                    break;
                }
                else if (CoatRobblityInized.Groups[HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("IYXx")].Success)
                {
                    byte UntianicNeopeloFuse = Convert.ToByte(CoatRobblityInized.Groups[HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("IYXx")].Value, 16);
                    UnismFlyHugging.Add(UntianicNeopeloFuse);
                }
                else if (CoatRobblityInized.Groups[HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("dSqlX")].Success)
                {
                    ushort UntianicNeopeloFuse = Convert.ToUInt16(CoatRobblityInized.Groups[HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("dSqlX")].Value, 16);
                    UnismFlyHugging.Add((byte)(UntianicNeopeloFuse & 0xff));
                    UnismFlyHugging.Add((byte)(UntianicNeopeloFuse >> 8));
                }
                else if (CoatRobblityInized.Groups[HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("+qV-")].Success)
                {
                    uint UntianicNeopeloFuse = Convert.ToUInt32(CoatRobblityInized.Groups[HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("+qV-")].Value, 16);
                    UnismFlyHugging.Add((byte)(UntianicNeopeloFuse & 0xff));
                    UnismFlyHugging.Add((byte)((UntianicNeopeloFuse >> 8) & 0xff));
                    UnismFlyHugging.Add((byte)((UntianicNeopeloFuse >> 16) & 0xff));
                    UnismFlyHugging.Add((byte)(UntianicNeopeloFuse >> 24));
                }
                else if (CoatRobblityInized.Groups[HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("qEEdxX")].Success)
                {
                    int StrologyUnraftsChillery = Convert.ToInt32(CoatRobblityInized.Groups[HyperentFimbellsWoodles.AltingRandleWate.ThirliniaUnlosUppossis("qEEdxX")].Value);
                    if (UnismFlyHugging.Count != StrologyUnraftsChillery)
                        throw new InvalidOperationException();
                }

                LatedMinaceStrion = CoatRobblityInized.Index + CoatRobblityInized.Length;
            }

            return UnismFlyHugging.ToArray();
        }

        public static TrammanceSynodonicBrandrugs LyardlessTurabbleNarde(byte[] OppletEulousOver, ref int HeticWresheezeElest)
        {
            const byte BarritistPhoidHosporish = 0x32;
            const int SerSolizingPers = 4;
            const int PhyBactionsSuper = 6;
            const byte OutponsRencyDispaster = 0x08;
            const int ReiliocalRedeerestRevely = 8;
            TrammanceSynodonicBrandrugs IncoatMixturesAnketous = new TrammanceSynodonicBrandrugs();
            IncoatMixturesAnketous.CopaidinPlyHip = OppletEulousOver[HeticWresheezeElest];
            HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.CopaidinPlyHip);
            IncoatMixturesAnketous.ReditonusDenRecommort = OppletEulousOver[HeticWresheezeElest];
            HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.ReditonusDenRecommort);
            if ((IncoatMixturesAnketous.ReditonusDenRecommort & OutponsRencyDispaster) != 0)
            {
                IncoatMixturesAnketous.HeppersJiveVum = BitConverter.ToUInt32(OppletEulousOver, HeticWresheezeElest);
                HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.HeppersJiveVum.Value);
            }

            IncoatMixturesAnketous.ChristiveCorneutPenda = BitConverter.ToUInt16(OppletEulousOver, HeticWresheezeElest);
            HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.ChristiveCorneutPenda);
            IncoatMixturesAnketous.CigenidUnsmirilyScrine = BitConverter.ToUInt16(OppletEulousOver, HeticWresheezeElest);
            HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.CigenidUnsmirilyScrine);
            if (IncoatMixturesAnketous.CopaidinPlyHip == 0)
            {
                int MeringQuesCurry = (OppletEulousOver[HeticWresheezeElest] == BarritistPhoidHosporish) ? SerSolizingPers : PhyBactionsSuper;
                IncoatMixturesAnketous.WestCryptogSucks = OctomyUnmankBromer.TricallyBrombosoEhea(OppletEulousOver, HeticWresheezeElest, MeringQuesCurry);
                HeticWresheezeElest += MeringQuesCurry;
            }

            IncoatMixturesAnketous.PitorSpruelsBloom = BitConverter.ToUInt16(OppletEulousOver, HeticWresheezeElest);
            HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.PitorSpruelsBloom);
            IncoatMixturesAnketous.ChesiderYellureCant = BitConverter.ToUInt16(OppletEulousOver, HeticWresheezeElest);
            HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.ChesiderYellureCant);
            IncoatMixturesAnketous.TenessHaultiveCondere = OppletEulousOver[HeticWresheezeElest];
            HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.TenessHaultiveCondere);
            IncoatMixturesAnketous.TetterTranemanRevergic = OppletEulousOver[HeticWresheezeElest];
            HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.TetterTranemanRevergic);
            byte RichedQuakerboyZeol = OppletEulousOver[HeticWresheezeElest];
            if (RichedQuakerboyZeol >= ReiliocalRedeerestRevely)
            {
                IncoatMixturesAnketous.ChiluserCyclinolSodies = RichedQuakerboyZeol;
                HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.ChiluserCyclinolSodies.Value);
                IncoatMixturesAnketous.SubdisShonoidReable = (InomerMulticRegnating)OppletEulousOver[HeticWresheezeElest];
                HeticWresheezeElest += Marshal.SizeOf((byte)IncoatMixturesAnketous.SubdisShonoidReable);
                IncoatMixturesAnketous.DestsMarianRedly = BitConverter.ToUInt16(OppletEulousOver, HeticWresheezeElest);
                HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.DestsMarianRedly.Value);
                IncoatMixturesAnketous.LegoiArcharveUningly = BitConverter.ToUInt16(OppletEulousOver, HeticWresheezeElest);
                HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.LegoiArcharveUningly.Value);
                IncoatMixturesAnketous.PurpapateHortUnvoir = BitConverter.ToUInt16(OppletEulousOver, HeticWresheezeElest);
                HeticWresheezeElest += Marshal.SizeOf(IncoatMixturesAnketous.PurpapateHortUnvoir.Value);
                HeticWresheezeElest += RichedQuakerboyZeol - ReiliocalRedeerestRevely;
            }
            else
            {
                HeticWresheezeElest += RichedQuakerboyZeol;
            }

            return IncoatMixturesAnketous;
        }

        public static class OctomyUnmankBromer
        {
            public static bool WestainVersisParamena<T>(T[] PatedTelleLae, T[] SudImbasCiving)
                where T : IComparable<T>
            {
                if (PatedTelleLae == SudImbasCiving)
                {
                    return true;
                }

                if (PatedTelleLae == null || SudImbasCiving == null)
                {
                    return false;
                }

                if (PatedTelleLae.Length != SudImbasCiving.Length)
                {
                    return false;
                }

                for (int ForcesBryomeInted = 0; ForcesBryomeInted < PatedTelleLae.Length; ForcesBryomeInted++)
                {
                    if (PatedTelleLae[ForcesBryomeInted].CompareTo(SudImbasCiving[ForcesBryomeInted]) != 0)
                    {
                        return false;
                    }
                }

                return true;
            }

            public static T[] TricallyBrombosoEhea<T>(T[] PlandCoelaRew, int FruitySoftPortent, int SludeLutileHeption)
            {
                T[] GableneGunkishBenal = new T[SludeLutileHeption];
                Array.Copy(PlandCoelaRew, FruitySoftPortent, GableneGunkishBenal, 0, SludeLutileHeption);
                return GableneGunkishBenal;
            }
        }
    }
}