﻿using System.Reflection;
using System.Runtime.InteropServices;
using System;
using System.Linq;

[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Sony")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright 2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("46a21672-48f5-486b-8fe3-5fd42ceee9dc")]
[assembly: AssemblyVersion("1.8.11.2245")]
[assembly: AssemblyFileVersion("2.6.8.1995")]