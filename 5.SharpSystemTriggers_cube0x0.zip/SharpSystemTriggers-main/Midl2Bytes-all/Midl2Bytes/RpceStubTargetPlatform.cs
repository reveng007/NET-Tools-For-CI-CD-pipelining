﻿using System;
using System.Linq;

namespace AqualNonrienicDezkiriae
{
    [Flags]
    public enum DialConsocityCrafted
    {
        BodiagnesScabrandaDecest = 1,
        FeudablerFlightReed = 2
    }
}