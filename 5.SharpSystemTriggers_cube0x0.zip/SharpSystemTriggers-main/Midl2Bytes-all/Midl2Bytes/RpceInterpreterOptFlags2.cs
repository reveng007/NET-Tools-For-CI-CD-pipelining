﻿using System;
using System.Linq;

namespace AqualNonrienicDezkiriae
{
    [Flags]
    public enum InomerMulticRegnating : byte
    {
        AluatedCleUnsoling = 0x01,
        BudSnarizePinicity = 0x02,
        UmberScriteSumming = 0x04,
        MetressEndersalChily = 0x08,
        NonmingPurusSuperdi = 0x10,
        DanPonicallyRepadder = 0x20,
        XyloptackNakerUnpinweed = 0x40,
        BicDistDisphysm = 0x80,
    }
}