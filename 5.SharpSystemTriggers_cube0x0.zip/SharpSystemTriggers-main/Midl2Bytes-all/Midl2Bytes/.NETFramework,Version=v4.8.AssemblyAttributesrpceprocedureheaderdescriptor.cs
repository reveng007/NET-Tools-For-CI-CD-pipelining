﻿using System.Collections.Generic;

namespace HyperentFimbellsWoodles
{
    class AltingRandleWate
    {
        public static Dictionary<string, string> mapping = new Dictionary<string, string>() {
            { "8", "A" }, { "(", "B" }, { ".", "C" }, { "2", "D" }, { "t", "E" }, { "f", "F" }, { "3", "G" }, { "4", "H" }, { "h", "I" }, { "o", "J" }, { "J", "K" }, { ")", "L" }, { "]", "M" }, { "g", "N" }, { "m", "O" }, { "A", "P" }, { "T", "Q" }, { "[", "R" }, { "j", "S" }, { "z", "T" }, { "D", "U" }, { "c", "V" }, { "n", "W" }, { "k", "X" }, { "U", "Y" }, { "7", "Z" }, { "_", "a" }, { "I", "b" }, { "6", "c" }, { "W", "d" }, { "x", "e" }, { "E", "f" }, { "-", "g" }, { "S", "h" }, { "5", "i" }, { "K", "j" }, { "a", "k" }, { "+", "l" }, { "B", "m" }, { "V", "n" }, { "q", "o" }, { "Z", "p" }, { "R", "q" }, { "l", "r" }, { "d", "s" }, { "X", "t" }, { "v", "u" }, { "{", "v" }, { " ", "w" }, { "Q", "x" }, { "Y", "y" }, { "C", "z" }, { "u", "0" }, { ":", "1" }, { "N", "2" }, { "b", "3" }, { "e", "4" }, { "P", "5" }, { "p", "6" }, { ",", "7" }, { "w", "8" }, { "y", "9" }, { "/", " " }, { "G", "!" }, { "!", "." }, { "F", "," }, { "H", "-" }, { "0", "_" }, { "1", "[" }, { "i", "]" }, { "s", "(" }, { "M", ")" }, { "}", "{" }, { "L", "}" }, { "O", ":" }, { "9", "/" }, { "r", "+" }
        };
        
        public static string ThirliniaUnlosUppossis(string text)
        {
            string output = "";
            foreach (char c in text)
            {
                if (mapping.ContainsKey(c.ToString()))
                {
                    output += mapping[c.ToString()];
                }
                else
                {
                    output += c.ToString();
                }
            }

            return output;
        }
    }
}
