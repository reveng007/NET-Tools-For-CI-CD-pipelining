﻿using System.Collections.Generic;

namespace ArganoralPolybingGigglues
{
    class ConnatedWhalousUnkney
    {
        public static Dictionary<string, string> mapping = new Dictionary<string, string>() {
            { "O", "A" }, { "I", "B" }, { "o", "C" }, { ")", "D" }, { "E", "E" }, { "(", "F" }, { "d", "G" }, { "[", "H" }, { "S", "I" }, { "m", "J" }, { " ", "K" }, { "M", "L" }, { "X", "M" }, { "!", "N" }, { "c", "O" }, { "N", "P" }, { "x", "Q" }, { "C", "R" }, { "2", "S" }, { "e", "T" }, { "W", "U" }, { "G", "V" }, { "l", "W" }, { "k", "X" }, { "L", "Y" }, { "{", "Z" }, { "t", "a" }, { ":", "b" }, { "1", "c" }, { "_", "d" }, { "0", "e" }, { "T", "f" }, { "/", "g" }, { "b", "h" }, { "s", "i" }, { "u", "j" }, { "J", "k" }, { "Z", "l" }, { "P", "m" }, { "p", "n" }, { "w", "o" }, { "V", "p" }, { "4", "q" }, { "6", "r" }, { "H", "s" }, { "D", "t" }, { "r", "u" }, { "Y", "v" }, { "}", "w" }, { "y", "x" }, { "i", "y" }, { "U", "z" }, { "Q", "0" }, { "A", "1" }, { "8", "2" }, { "K", "3" }, { "5", "4" }, { "F", "5" }, { ",", "6" }, { "a", "7" }, { "n", "8" }, { "q", "9" }, { "g", " " }, { "j", "!" }, { "-", "." }, { "7", "," }, { "f", "-" }, { "+", "_" }, { "h", "[" }, { ".", "]" }, { "B", "(" }, { "v", ")" }, { "]", "{" }, { "R", "}" }, { "9", ":" }, { "z", "/" }, { "3", "+" }
        };
        
        public static string TuffetticProcarpMotheism(string text)
        {
            string output = "";
            foreach (char c in text)
            {
                if (mapping.ContainsKey(c.ToString()))
                {
                    output += mapping[c.ToString()];
                }
                else
                {
                    output += c.ToString();
                }
            }

            return output;
        }
    }
}
