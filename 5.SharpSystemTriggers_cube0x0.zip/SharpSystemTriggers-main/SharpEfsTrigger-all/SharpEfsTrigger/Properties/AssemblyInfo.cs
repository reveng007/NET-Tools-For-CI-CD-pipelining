﻿using System.Reflection;
using System.Runtime.InteropServices;
using System;
using System.Linq;

[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ivanti")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright 2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("730d3858-7eda-4c9a-ac7d-eef288ba78d8")]
[assembly: AssemblyVersion("3.0.13.2834")]
[assembly: AssemblyFileVersion("5.9.4.1720")]