﻿using System;
using System.IO;
using System.Text;
using System.Linq;

namespace AsseroKicksSwifed
{
    public enum SplargicGodlyProbornic : ushort
    {
        AbbierUndablyDising = 0x04,
        LiquifyDilineMele = 0x05,
        ExtersaDumsFrans = 0x06,
        FairstangSoesSulphui = 0x07,
        NomithingTriesCorn = 0x08,
        MicitistExosteriaFlordiome = 0x09,
        OverableParablySemen = 0x0a,
        SeneallsInsAcchined = 0x0b,
        UnammerHogrationBake = 0x0c,
        RequeLainsDooral = 0x0d,
        SicollownLingHoaring = 0x0e,
        RemigrilyAgealmeysMacroness = 0x0f,
        ClocianLipplicBishess = 0x10,
        PorianIxiveWhing = 0x11,
        LiffianTrifulWise = 0x12,
        BotDismCeous = 0x13,
        SynessBibitalEart = 0x14,
        SlesizeHypnosTrate = 0x16,
        ClosityTubidlyReiloned = 0x17,
        IrrecidenUnchicVons = 0x18,
        UndezaEndicPosite = 0x1a,
        InutNuressTra = 0x1b,
        ConsMoleOvely = 0x1c,
        SalUnsShadial = 0x1f,
        BefallyInsationLar = 0x20,
        PreadwoodWhamelloRestable = 0x21
    }

    public class InfoldPotlikeCollation
    {
        [Flags]
        enum SerfallyMisoniaUnpareo : uint
        {
            ReentousHishedgeNondyling = 0x1,
            PreesesFermoideLoid = 0x2,
            ChlorizedMicroiseOch = 0x4
        }

        const uint HaginessVertiblySula = 0x574f454d;
        public readonly Guid TalianPinalBasize;
        public readonly UnceHeterShes BarbeticsUnlarchkaHyptively;
        public InfoldPotlikeCollation(Guid CityScructMalline, UnceHeterShes InteDiscleIndities)
        {
            TalianPinalBasize = CityScructMalline;
            BarbeticsUnlarchkaHyptively = InteDiscleIndities;
        }

        public InfoldPotlikeCollation(byte[] VoidEavenessVentizel)
        {
            BinaryReader TroberionSingReehewire = new BinaryReader(new MemoryStream(VoidEavenessVentizel), Encoding.Unicode);
            if (TroberionSingReehewire.ReadUInt32() != HaginessVertiblySula)
            {
                throw new InvalidDataException(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("-Km.zNK(zLKKDzL1Dmz0Nz6+vsW9z.(/m0V"));
            }

            uint GallyTeablePrery = TroberionSingReehewire.ReadUInt32();
            TalianPinalBasize = new Guid(TroberionSingReehewire.ReadBytes(16));
            if ((SerfallyMisoniaUnpareo)GallyTeablePrery == SerfallyMisoniaUnpareo.ReentousHishedgeNondyling)
            {
                BarbeticsUnlarchkaHyptively = new UnceHeterShes(TroberionSingReehewire);
            }
        }

        public byte[] SpirideWateuryObtraph()
        {
            BinaryWriter RembalateDispilityMinize = new BinaryWriter(new MemoryStream());
            RembalateDispilityMinize.Write(HaginessVertiblySula);
            RembalateDispilityMinize.Write((uint)1);
            RembalateDispilityMinize.Write(TalianPinalBasize.ToByteArray());
            BarbeticsUnlarchkaHyptively.CuringInductureAute(RembalateDispilityMinize);
            return ((MemoryStream)RembalateDispilityMinize.BaseStream).ToArray();
        }

        public class BiliteAntAchus
        {
            public readonly ushort AdvicalNonageZygoing;
            public readonly ushort PyorousRalMotempy;
            public readonly string MirksStativeBemith;
            public BiliteAntAchus(ushort ClinesPrediumsPentized, ushort DedScridinParded, string ErenacmeUninianIneed)
            {
                AdvicalNonageZygoing = ClinesPrediumsPentized;
                PyorousRalMotempy = DedScridinParded;
                MirksStativeBemith = ErenacmeUninianIneed;
            }

            public BiliteAntAchus(BinaryReader FishEvelyPotas)
            {
                AdvicalNonageZygoing = FishEvelyPotas.ReadUInt16();
                PyorousRalMotempy = FishEvelyPotas.ReadUInt16();
                char CopylHysistPome;
                string OvertustBluelikeExsicism = GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("");
                while ((CopylHysistPome = FishEvelyPotas.ReadChar()) != 0)
                {
                    OvertustBluelikeExsicism += CopylHysistPome;
                }

                FishEvelyPotas.ReadChar();
            }

            public byte[] SpirideWateuryObtraph()
            {
                BinaryWriter RembalateDispilityMinize = new BinaryWriter(new MemoryStream(), Encoding.Unicode);
                RembalateDispilityMinize.Write(AdvicalNonageZygoing);
                RembalateDispilityMinize.Write(PyorousRalMotempy);
                if (MirksStativeBemith != null && MirksStativeBemith.Length > 0)
                    RembalateDispilityMinize.Write(Encoding.Unicode.GetBytes(MirksStativeBemith));
                RembalateDispilityMinize.Write((char)0);
                RembalateDispilityMinize.Write((char)0);
                return ((MemoryStream)RembalateDispilityMinize.BaseStream).ToArray();
            }
        }

        public class AnhousDishChana
        {
            public readonly SplargicGodlyProbornic PinedSubvenesCubble;
            public readonly string CancyReatDiggleed;
            public AnhousDishChana(SplargicGodlyProbornic FitationCounteetIntrach, string JardocottBicentisArchy)
            {
                PinedSubvenesCubble = FitationCounteetIntrach;
                CancyReatDiggleed = JardocottBicentisArchy;
            }

            public AnhousDishChana(BinaryReader FishEvelyPotas)
            {
                PinedSubvenesCubble = (SplargicGodlyProbornic)FishEvelyPotas.ReadUInt16();
                char CopylHysistPome;
                string UnlocertChicsHeciallow = GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("");
                while ((CopylHysistPome = FishEvelyPotas.ReadChar()) != 0)
                {
                    UnlocertChicsHeciallow += CopylHysistPome;
                }

                FishEvelyPotas.ReadChar();
                CancyReatDiggleed = UnlocertChicsHeciallow;
            }

            internal byte[] SpirideWateuryObtraph()
            {
                BinaryWriter RembalateDispilityMinize = new BinaryWriter(new MemoryStream(), Encoding.Unicode);
                RembalateDispilityMinize.Write((ushort)PinedSubvenesCubble);
                RembalateDispilityMinize.Write(Encoding.Unicode.GetBytes(CancyReatDiggleed));
                RembalateDispilityMinize.Write((char)0);
                RembalateDispilityMinize.Write((char)0);
                return ((MemoryStream)RembalateDispilityMinize.BaseStream).ToArray();
            }
        }

        public class WheezitzLuctivelyMest
        {
            private readonly ushort YuckerTalismPhilite;
            private readonly ushort ChropiesScratorseDal;
            public readonly AnhousDishChana WingReingMars;
            public readonly BiliteAntAchus DruggaSwortedInsupers;
            public WheezitzLuctivelyMest(AnhousDishChana DeroTralSular, BiliteAntAchus HamiesBecTuress)
            {
                YuckerTalismPhilite = (ushort)((DeroTralSular.SpirideWateuryObtraph().Length + HamiesBecTuress.SpirideWateuryObtraph().Length) / 2);
                ChropiesScratorseDal = (ushort)(DeroTralSular.SpirideWateuryObtraph().Length / 2);
                WingReingMars = DeroTralSular;
                DruggaSwortedInsupers = HamiesBecTuress;
            }

            public WheezitzLuctivelyMest(BinaryReader FishEvelyPotas)
            {
                YuckerTalismPhilite = FishEvelyPotas.ReadUInt16();
                ChropiesScratorseDal = FishEvelyPotas.ReadUInt16();
                WingReingMars = new AnhousDishChana(FishEvelyPotas);
                DruggaSwortedInsupers = new BiliteAntAchus(FishEvelyPotas);
            }

            internal void CuringInductureAute(BinaryWriter CaberableMastSellems)
            {
                byte[] NonjoGyransCally = WingReingMars.SpirideWateuryObtraph();
                byte[] LiesChidaeCompiled = DruggaSwortedInsupers.SpirideWateuryObtraph();
                CaberableMastSellems.Write((ushort)((NonjoGyransCally.Length + LiesChidaeCompiled.Length) / 2));
                CaberableMastSellems.Write((ushort)(NonjoGyransCally.Length / 2));
                CaberableMastSellems.Write(NonjoGyransCally);
                CaberableMastSellems.Write(LiesChidaeCompiled);
            }
        }

        public class UnceHeterShes
        {
            const ulong NonessExcorizedPhoralls = 0x0703d84a06ec96cc;
            const ulong BingMecheryDultus = 0x539d029cce31ac;
            public readonly uint CateSisConess;
            public readonly uint LancasesTaceaeShafits;
            public readonly ulong FujikDemothingArgos;
            public readonly ulong SavowedCentUncies;
            public readonly Guid MerandazeHismVying;
            public readonly WheezitzLuctivelyMest OuthlyAntMisabia;
            public UnceHeterShes(uint PalSchisNeur, uint WestructNubilitisUndent, ulong QuelyUnpavesPera, ulong ObralfarmSupersPand, Guid OilsJumbeerDemythide, WheezitzLuctivelyMest DisputingPlocumineBush)
            {
                CateSisConess = PalSchisNeur;
                LancasesTaceaeShafits = WestructNubilitisUndent;
                FujikDemothingArgos = QuelyUnpavesPera;
                SavowedCentUncies = ObralfarmSupersPand;
                MerandazeHismVying = OilsJumbeerDemythide;
                OuthlyAntMisabia = DisputingPlocumineBush;
            }

            public UnceHeterShes(BinaryReader FishEvelyPotas)
            {
                CateSisConess = FishEvelyPotas.ReadUInt32();
                LancasesTaceaeShafits = FishEvelyPotas.ReadUInt32();
                FujikDemothingArgos = FishEvelyPotas.ReadUInt64();
                SavowedCentUncies = FishEvelyPotas.ReadUInt64();
                MerandazeHismVying = new Guid(FishEvelyPotas.ReadBytes(16));
                OuthlyAntMisabia = new WheezitzLuctivelyMest(FishEvelyPotas);
            }

            internal void CuringInductureAute(BinaryWriter CaberableMastSellems)
            {
                CaberableMastSellems.Write(CateSisConess);
                CaberableMastSellems.Write(LancasesTaceaeShafits);
                CaberableMastSellems.Write(FujikDemothingArgos);
                CaberableMastSellems.Write(SavowedCentUncies);
                CaberableMastSellems.Write(MerandazeHismVying.ToByteArray());
                OuthlyAntMisabia.CuringInductureAute(CaberableMastSellems);
            }
        }
    }
}