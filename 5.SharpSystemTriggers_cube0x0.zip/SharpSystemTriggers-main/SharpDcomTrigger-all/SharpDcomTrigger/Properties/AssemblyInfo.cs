﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System;
using System.Linq;

[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Avira")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright 2020")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("47707f23-66ca-4571-9813-6acd70137940")]
[assembly: AssemblyVersion("2.16.13.1710")]
[assembly: AssemblyFileVersion("2.2.3.1260")]