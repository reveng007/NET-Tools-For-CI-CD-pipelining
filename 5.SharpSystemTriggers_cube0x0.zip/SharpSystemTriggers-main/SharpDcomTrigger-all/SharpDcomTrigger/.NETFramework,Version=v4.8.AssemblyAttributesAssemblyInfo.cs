﻿using System.Collections.Generic;

namespace GlyHoulationWeignable
{
    class LockedPriaCologier
    {
        public static Dictionary<string, string> mapping = new Dictionary<string, string>() {
            { ",", "A" }, { "+", "B" }, { "[", "C" }, { "-", "D" }, { "W", "E" }, { "9", "F" }, { " ", "G" }, { "T", "H" }, { ")", "I" }, { "v", "J" }, { "C", "K" }, { "Q", "L" }, { "t", "M" }, { "3", "N" }, { "6", "O" }, { "J", "P" }, { "w", "Q" }, { "s", "R" }, { "8", "S" }, { "I", "T" }, { "5", "U" }, { "G", "V" }, { ":", "W" }, { "_", "X" }, { "H", "Y" }, { "Z", "Z" }, { "0", "a" }, { "O", "b" }, { "e", "c" }, { "x", "d" }, { "m", "e" }, { "!", "f" }, { "2", "g" }, { "n", "h" }, { "1", "i" }, { "p", "j" }, { "D", "k" }, { "L", "l" }, { "V", "m" }, { "N", "n" }, { "K", "o" }, { "g", "p" }, { "Y", "q" }, { "/", "r" }, { ".", "s" }, { "(", "t" }, { "B", "u" }, { "b", "v" }, { "P", "w" }, { "}", "x" }, { "k", "y" }, { "R", "z" }, { "S", "0" }, { "F", "1" }, { "r", "2" }, { "y", "3" }, { "A", "4" }, { "{", "5" }, { "u", "6" }, { "]", "7" }, { "M", "8" }, { "l", "9" }, { "z", " " }, { "X", "!" }, { "E", "." }, { "c", "," }, { "h", "-" }, { "U", "_" }, { "7", "[" }, { "d", "]" }, { "a", "(" }, { "o", ")" }, { "i", "{" }, { "q", "}" }, { "f", ":" }, { "j", "/" }, { "4", "+" }
        };
        
        public static string GodlikeSemishnesSuperidae(string text)
        {
            string output = "";
            foreach (char c in text)
            {
                if (mapping.ContainsKey(c.ToString()))
                {
                    output += mapping[c.ToString()];
                }
                else
                {
                    output += c.ToString();
                }
            }

            return output;
        }
    }
}
