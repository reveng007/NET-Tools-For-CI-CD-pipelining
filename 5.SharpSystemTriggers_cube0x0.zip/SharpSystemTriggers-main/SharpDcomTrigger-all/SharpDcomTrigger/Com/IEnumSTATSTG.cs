﻿using System;
using System.Runtime.InteropServices;
using System.Linq;

namespace AsseroKicksSwifed.TaceaeSchaNan
{
    [ComImport]
    [Guid("47707f23-66ca-4571-9813-6acd70137940")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IEnumSTATSTG
    {
        [PreserveSig]
        uint AnakeholeUnhumohipBlasmic(uint MusicExegeryGrowarde, [MarshalAs(UnmanagedType.LPArray), Out] STATSTG[] ObserEnroonNapped, out uint MuschilyNaphicsNing);
        void DialisedEnlikePhosphens(uint MusicExegeryGrowarde);
        void MurplandNonsiveShope();
        [return: MarshalAs(UnmanagedType.Interface)]
        IEnumSTATSTG RouslyCoafishReing();
    }
}