﻿using System;
using System.Runtime.InteropServices;
using System.Linq;

namespace AsseroKicksSwifed.TaceaeSchaNan
{
    [ComVisible(false)]
    [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("47707f23-66ca-4571-9813-6acd70137940")]
    public interface ILockBytes
    {
        void MismsBowerAmed(long GoetancePectornsZelion, System.IntPtr TolustfulGaspeckPuddling, int UnseizingSponsAntdown, out System.UInt32 HailmenMeliberGimprotei);
        void SquinableBayzgoofUtch(long GoetancePectornsZelion, System.IntPtr TolustfulGaspeckPuddling, int UnseizingSponsAntdown, out System.UInt32 MetransAnizesQuiven);
        void OvermalsWardsInated();
        void ModiatedPhishnicAlm(long UnseizingSponsAntdown);
        void DoniatedTheServeness(long QuruxingBashriesCadepo, long UnseizingSponsAntdown, int AdruminaForfrijaOuts);
        void NittesBioatChards(long QuruxingBashriesCadepo, long UnseizingSponsAntdown, int AdruminaForfrijaOuts);
        void LeurDeciallySqrf(out System.Runtime.InteropServices.STATSTG SemationAntituleArdits, int PalsPolyaLages);
    }
}