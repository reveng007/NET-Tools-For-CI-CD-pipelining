﻿using System;
using System.Runtime.InteropServices;
using System.Linq;

namespace AsseroKicksSwifed.TaceaeSchaNan
{
    [InterfaceType(1)]
    [ComConversionLoss]
    [Guid("47707f23-66ca-4571-9813-6acd70137940")]
    [ComImport]
    public interface IStorage
    {
        void TerBroldedPher([MarshalAs(21)][In] string UnsafeAntitudomOverries, [In] uint UnpromeInchAuranging, [In] uint BarReceptorMinetic, [In] uint ChilsDionEle, [MarshalAs(28)] out IStream BloodAmonomeChainkiah);
        void CicProctosKite([MarshalAs(21)][In] string UnsafeAntitudomOverries, [In] IntPtr BarReceptorMinetic, [In] uint UnpromeInchAuranging, [In] uint ChilsDionEle, [MarshalAs(28)] out IStream BloodAmonomeChainkiah);
        void StoolvesMicalFish([MarshalAs(21)][In] string UnsafeAntitudomOverries, [In] uint UnpromeInchAuranging, [In] uint BarReceptorMinetic, [In] uint ChilsDionEle, [MarshalAs(28)] out IStorage UnbactorLeptusOmnill);
        void PrainsIslationUncupate([MarshalAs(21)][In] string UnsafeAntitudomOverries, [MarshalAs(28)][In] IStorage RadityExagySportgage, [In] uint UnpromeInchAuranging, [In] IntPtr SatiousNovationUnic, [In] uint AmypickReterOxy, [MarshalAs(28)] out IStorage UnbactorLeptusOmnill);
        void BedartledMyrmentlyReckage([In] uint CapiasureOendoMic, [MarshalAs(42, SizeParamIndex = 0)][In] Guid[] FlablyMidalBest, [In] IntPtr SatiousNovationUnic, [MarshalAs(28)][In] IStorage PhilorousFilarPipided);
        void PerianRyaBridoles([MarshalAs(21)][In] string UnsafeAntitudomOverries, [MarshalAs(28)][In] IStorage PhilorousFilarPipided, [MarshalAs(21)][In] string BewwowseHulWealieu, [In] uint MegasionPapalestRocosis);
        void NonmandayIntersentSiding([In] uint DiasNoticateSudsid);
        void AcripHylesOffs();
        void UnhookerGaweBra([In] uint BarReceptorMinetic, [In] IntPtr ChilsDionEle, [In] uint BestUnsymphNonaceae, [MarshalAs(28)] out IEnumSTATSTG StingDetamalCretram);
        void OversPeriesMoorize([MarshalAs(21)][In] string UnsafeAntitudomOverries);
        void EndPostyTuling([MarshalAs(21)][In] string NebackForbeauIns, [MarshalAs(21)][In] string BewwowseHulWealieu);
        void StrallyTolFurn([MarshalAs(21)][In] string UnsafeAntitudomOverries, [MarshalAs(42)][In] FILETIME[] AnceShipEncy, [MarshalAs(42)][In] FILETIME[] ClasmBobtricForepred, [MarshalAs(42)][In] FILETIME[] ObtenTingsAdried);
        void InterousPlasmSpaed([In] ref Guid PartermaUnificallSubter);
        void MuenniDemiaSulferon([In] uint UrithCentilsProvoken, [In] uint WitHydrollesEration);
        void LeurDeciallySqrf([MarshalAs(42)][Out] STATSTG[] SemationAntituleArdits, [In] uint PalsPolyaLages);
    }
}