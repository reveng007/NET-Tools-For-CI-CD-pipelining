﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SharpSCCM")]
[assembly: AssemblyDescription("A C# utility for interacting with SCCM")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SharpSCCM")]
[assembly: AssemblyCopyright("© 2024 Chris Thompson (@_Mayyhem)")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("e4d9ef39-0fce-4573-978b-abf8df6aec23")]

// Version information for this assembly consists of the following three values:
//
//      Major Version
//      Minor Version
//      Revision
//
[assembly: AssemblyVersion("2.0.12")]
[assembly: AssemblyFileVersion("2.0.12")]
