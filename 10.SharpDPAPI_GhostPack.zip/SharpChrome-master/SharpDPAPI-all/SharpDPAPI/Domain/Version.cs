﻿using System;

namespace SharpDPAPI
{
    public static class Version
    {
        public static string version = "1.12.0";
    }
}
