﻿using SharpView.Enums;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace SharpView.Arguments
{
    public class Args_Get_DomainGPOComputerLocalGroupMapping
    {
        public string ComputerIdentity { get; set; }
        public string ComputerName { get { return ComputerIdentity; } set { ComputerIdentity = value; } }
        public string Computer { get { return ComputerIdentity; } set { ComputerIdentity = value; } }
        public string DistinguishedName { get { return ComputerIdentity; } set { ComputerIdentity = value; } }
        public string SamAccountName { get { return ComputerIdentity; } set { ComputerIdentity = value; } }
        public string Name { get { return ComputerIdentity; } set { ComputerIdentity = value; } }

        public string OUIdentity { get; set; }
        public string OU { get { return OUIdentity; } set { OUIdentity = value; } }

        public LocalGroupType LocalGroup { get; set; } = LocalGroupType.Administrators;

        public string Domain { get; set; }

        public string SearchBase { get; set; }
        public string ADSPath { get { return SearchBase; } set { SearchBase = value; } }

        public string Server { get; set; }
        public string DomainController { get { return Server; } set { Server = value; } }

        public SearchScope SearchScope { get; set; } = SearchScope.Subtree;

        private int _ResultPageSize = 200;
        public int ResultPageSize
        {
            get { return _ResultPageSize; }
            set
            {
                if (value < 1 || value > 10000) throw new ArgumentOutOfRangeException("ResultPageSize");
                _ResultPageSize = value;
            }
        }

        private int? _ServerTimeLimit;
        public int? ServerTimeLimit
        {
            get { return _ServerTimeLimit; }
            set
            {
                if (value < 1 || value > 10000) throw new ArgumentOutOfRangeException("ServerTimeLimit");
                _ServerTimeLimit = value;
            }
        }

        public bool Tombstone { get; set; }

        public NetworkCredential Credential { get; set; }
    }
}
