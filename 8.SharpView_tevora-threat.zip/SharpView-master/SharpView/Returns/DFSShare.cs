﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace SharpView.Returns
{
    public class DFSShare
    {
        public string Name { get; set; }

        public string RemoteServerName { get; set; }
    }
}
