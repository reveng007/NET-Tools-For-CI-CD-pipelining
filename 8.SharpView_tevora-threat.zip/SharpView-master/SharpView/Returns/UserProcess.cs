﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpView.Returns
{
    public class UserProcess
    {
        public string ComputerName { get; set; }

        public string ProcessName { get; set; }

        public string ProcessID { get; set; }

        public string Domain { get; set; }

        public string User { get; set; }
    }
}
